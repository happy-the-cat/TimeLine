package classes;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.awt.*;
import java.util.Random;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Iterator;

public class mainController {
    @FXML private TextField schedNameField;
    @FXML private TextField taskNameField;
    @FXML private Button addTaskBtn;
    @FXML private Button editTaskBtn;
    @FXML private Button removeTaskBtn;
    @FXML private GridPane schedPane;
    @FXML private ComboBox<LocalTime> timePicker;
    @FXML private ComboBox<DayOfWeek> weekDayPicker;
    @FXML private Label statusLabel;
    @FXML private ScrollPane scrollPane;
    @FXML private Label Tips,Tips1,Tips2;
    @FXML private Button sButton,rButton,lButton,sButton1,rButton1;
    @FXML private Text clockText,countdownText;
    @FXML private TextArea lapArea;
    @FXML private ComboBox<Integer> tHour,tMinute,tSec;
    private String userDir;
    // userDir = directory name where the user's schedules will be saved
    // schedNmae = filename of the opened schedule
    private final ArrayList<LocalTime> times = new ArrayList<>();
    private static Timeslot[][] schedule = null;
    // 2D array of TasksPerTime (schedule timeslot) that looks similar to schedPane.
    // row_idx = time (based on times) = schedPane's row index
    // col_idx = day of week (1-7) - 1 = schedPane's col index - 1
    private static Path schedPath = null;
    private final LocalTime startTime = LocalTime.of(0, 0);
    private final LocalTime endTime = LocalTime.of(23, 59);
    private final Duration timeGap = Duration.ofMinutes(30);
    private Timeline stopwatchT,timerT;
    private int stHours = 0, stMins = 0, stSecs = 0, stMillis = 0,stCount = 0,
            tiHours = 0, tiMins = 0, tiSecs = 0, tiMillis = 0,tiCount = 0;
    boolean stS = true,tiS = true;

    // Function to read random tip from tips.txt file
    @FXML
    private void randomTips(){
        try{
            // Opens file
            File files = new File("databases/tips.txt");
            int c=1;
            Scanner scanner = new Scanner(files);
            // Creates array to store later
            String[] list = new String[100];
            Random random = new Random();
            // random generator, while loop to get all tips
            while (scanner.hasNextLine()) {
                String l = scanner.nextLine();
                list[c] = l;
                c++;
            }
            int r = random.nextInt(c-1);
            // sets tip to labels
            Tips.setText(list[r]);
            Tips1.setText(list[r]);
            Tips2.setText(list[r]);
        } catch (FileNotFoundException e) {
            System.out.println("Error, please insert the valid files.");
        }
    }

    // Function to update per millisecond text
    private void change(Text text, int type) {
        // type 1 = stopwatch
        if (type == 1) {
            if (stMillis == 1000) {       // for max millis
                stSecs++;
                stMillis = 0;
            }
            if (stSecs == 60) {          // for max seconds
                stMins++;
                stSecs = 0;
            }
            if (stMins == 60) {          // for max minutes
                stHours++;
                stMins = 0;
            }
            // sets text with format
            clockText.setText((((stHours / 10) == 0) ? "0" : "") + stHours + ":"
                    + (((stMins / 10) == 0) ? "0" : "") + stMins + ":"
                    + (((stSecs / 10) == 0) ? "0" : "") + stSecs + ":"
                    + (((stMillis / 10) == 0) ? "00" : (((stMillis / 100) == 0) ? "0" : "")) + stMillis++);
        } // type 2 = timer
        else if (type == 2) {
            if (tiMillis <= 0 && tiSecs > 0) {  // for max millis
                tiSecs--;
                tiMillis = 999;
            }
            if (tiSecs <= 0 && tiMins > 0) { // for max seconds
                tiMins--;
                tiSecs = 59;
            }
            if (tiMins <= 0 && tiHours > 0) { // for max minutes
                tiHours--;
                tiMins = 59;
            }
            // condition to create popup once timer is done
            if (tiHours <= 0 && tiMins <= 0 && tiSecs <= 0 && tiMillis <= 0) {
                tiReset();
                sButton1.setDisable(true);  // disables start button
                handlePopup();             // popup function
            }
            // changes countdown text
            countdownText.setText((((tiHours / 10) == 0) ? "0" : "") + tiHours + ":"
                    + (((tiMins / 10) == 0) ? "0" : "") + tiMins + ":"
                    + (((tiSecs / 10) == 0) ? "0" : "") + tiSecs + ":"
                    + (((tiMillis / 10) == 0) ? "00" : (((tiMillis / 100) == 0) ? "0" : "")) + tiMillis--);
        }
    }

    // Popup function for timer
    private void handlePopup(){
        Alert a = new Alert(Alert.AlertType.NONE);
        a.setAlertType(Alert.AlertType.INFORMATION);
        a.setTitle("TimeLine");
        a.setHeaderText("Timer is done!");
        a.show();
        Toolkit.getDefaultToolkit().beep();
    }

    // Function to save current laptime
    @FXML
    private void lapR() {
        lapArea.appendText("Lap Number: " + stCount++ +" - "
                + (((stHours/10) == 0) ? "0" : "") + stHours + ":"
                + (((stMins/10) == 0) ? "0" : "") + stMins + ":"
                + (((stSecs/10) == 0) ? "0" : "") + stSecs + ":"
                + (((stMillis/10) == 0) ? "00" : (((stMillis/100) == 0) ? "0" : "")) + stMillis +'\n');
    }

    // Stopwatch start function
    @FXML
    private void stStart() {
        if(stS) {
            stopwatchT.play();         // starts stopwatch
            stS = false;
            sButton.setText("Pause");
            lButton.setDisable(false);
            randomTips();
        } else {
            stopwatchT.pause();        // pauses stopwatch
            stS = true;
            sButton.setText("Start");
            lButton.setDisable(true);
            randomTips();
        }
    }

    // timer start function
    @FXML
    private void tiStart() {
        if(tiCount==0)
        {
            tiHours = (int) tHour.getSelectionModel().getSelectedItem();
            tiMins = (int) tMinute.getSelectionModel().getSelectedItem();
            tiSecs = (int) tSec.getSelectionModel().getSelectedItem();
            tiCount++;
        }
        if(tiS) {
            timerT.play();
            tiS = false;
            sButton1.setText("Pause");
            randomTips();
        } else {
            timerT.pause();
            tiS = true;
            sButton1.setText("Start");
            randomTips();
        }
    }

    // reset stopwatch function
    @FXML
    private void stReset() {
        stHours = 0;
        stMins = 0;
        stSecs = 0;
        stMillis = 0;
        stCount = 0;
        stopwatchT.pause();
        clockText.setText("00:00:00:000");
        lapArea.clear();
        if(!stS) {
            stS = true;
            sButton.setText("Start");
        }
        randomTips();
    }

    // reset timer function
    @FXML
    private void tiReset() {
        sButton1.setDisable(false);
        timerT.pause();
        tiHours = 0;
        tiMins = 0;
        tiSecs = 0;
        tiMillis = 0;
        tiCount = 0;
        countdownText.setText("00:00:00:000");
        if(!tiS) {
            tiS = true;
            sButton.setText("Start");
        }
        randomTips();
    }

    // Initialize function; runs right after FXML is loaded
    @FXML
    private void initialize() {
        LocalTime time = startTime;
        // Set-up timeline for timer
        stopwatchT = new Timeline(new KeyFrame(javafx.util.Duration.millis(1), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                change(clockText,1);
            }
        }));
        stopwatchT.setCycleCount(Timeline.INDEFINITE);
        stopwatchT.setAutoReverse(false);
        // Set-up timeline for countdown
        timerT = new Timeline(new KeyFrame(javafx.util.Duration.millis(1), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                change(countdownText,2);
            }
        }));
        timerT.setCycleCount(Timeline.INDEFINITE);
        timerT.setAutoReverse(false);
        // Set-up times ArrayList and combo boxes.
        do {
            // Add time to times ArrayList.
            times.add(time);
            // Add as a choice in to timePicker combo box.
            timePicker.getItems().add(time);
            // Increment for next iteration.
            time = time.plus(timeGap);
        } while (!time.equals(startTime));
        // Set-up day of week combo box.
        weekDayPicker.getItems().addAll(DayOfWeek.values());
        disableTaskControls(true);
        statusLabel.setWrapText(true);
        randomTips();
        timerCombo();
    }

    //
    @FXML
    public void timerCombo(){
        tHour.getItems().removeAll(tHour.getItems());
        tMinute.getItems().removeAll(tHour.getItems());
        tSec.getItems().removeAll(tHour.getItems());
        for(int i = 0; i<=24; i ++) {
            tHour.getItems().addAll(i);
        }
        for(int j = 0; j<=59; j ++) {
            tMinute.getItems().addAll(j);
            tSec.getItems().addAll(j);
        }
        tHour.getSelectionModel().select(0);
        tMinute.getSelectionModel().select(0);
        tSec.getSelectionModel().select(1);
        randomTips();
    }

    // Handle create sched button
    @FXML
    private void handleCreateSched() {
        if (schedNameField.getText().isEmpty()) {
            statusLabel.setText("Invalid input!");
        }
        else if (Files.exists(Path.of(userDir + schedNameField.getText() + ".txt"))) {
            statusLabel.setText("Schedule already exists!");
        }
        else {
            // Save existing schedule and clear schedPane, if any
            if (schedPath != null) {
                saveSched();
                schedPane.getChildren().clear();
            }
            // Initialize size of schedule array
            schedule = new Timeslot[getTimeIdx(endTime)][7];
            try {
                schedPath = Files.createFile(Path.of(
                        userDir + schedNameField.getText() + ".txt"));
                statusLabel.setText("Schedule created successfully!");
            } catch (IOException e) {
                statusLabel.setText("An error occurred.");
                e.printStackTrace();
            }
            initializeSchedule();
            setupSchedPane();
            if (addTaskBtn.isDisable()) {
                disableTaskControls(false);
            }
        }
        schedNameField.clear();
        randomTips();
    }

    // Handle open sched button
    @FXML
    private void handleOpenSched() {
        if (schedNameField.getText().isEmpty()) {
            statusLabel.setText("Invalid input!");
        }
        else if (!Files.exists(Path.of(userDir + schedNameField.getText() + ".txt"))) {
            statusLabel.setText("Schedule not found!");
        }
        else {
            // Save existing schedule and clear schedPane, if any
            if (schedPath != null) {
                saveSched();
                schedPane.getChildren().clear();
            }
            schedPath = Path.of(userDir + schedNameField.getText() + ".txt");
            // Initialize new schedule array size
            schedule = new Timeslot[getTimeIdx(endTime)][7];
            loadSched();
            setupSchedPane();
            statusLabel.setText("Schedule loaded successfully!");
            if (addTaskBtn.isDisable()) {
                disableTaskControls(false);
            }
        }
        schedNameField.clear();
        randomTips();
    }

    // Handle delete sched button
    @FXML
    private void handleDeleteSched() {
        Path path;
        if (schedNameField.getText().isEmpty()) {
            statusLabel.setText("Invalid input!");
            return;
        }
        path = Path.of(userDir + schedNameField.getText() + ".txt");
        try {
            if (Files.deleteIfExists(path)) {
                statusLabel.setText("Schedule deleted successfully!");
                if (schedPath!=null && schedPath.equals(path)) {
                    schedPath = null;
                    schedPane.getChildren().clear();
                    schedule = null;
                    disableTaskControls(true);
                } else {
                    saveSched();
                }
            } else {
                statusLabel.setText("Schedule not found!");
            }
        } catch (IOException e) {
            statusLabel.setText("An error occurred.");
            e.printStackTrace();
        }
        randomTips();
    }

    // Handle Logout Button
    @FXML
    private void handleLogout() {
        saveSched();
        // get the stage statusLabel belongs to
        Stage primaryStage = (Stage) statusLabel.getScene().getWindow();
        try {
            // load loginUI.fxml
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("../scenes/loginUI.fxml"));
            Parent root = fxmlLoader.load();
            // swap scene
            primaryStage.setScene(new Scene(root, 700, 400));
        } catch (IOException e) {
            e.getCause();
        }
    }

    // Handle add task button
    @FXML
    private void handleAddTask() {
        if (taskNameField.getText().isEmpty() ||
                timePicker.getSelectionModel().isEmpty() ||
                weekDayPicker.getSelectionModel().isEmpty()) {
            statusLabel.setText("Incomplete Input!");
            return;
        }
        LocalTime time = timePicker.getValue();
        // Get the index of the chosen time in times list to serve as row # of schedPaneList.
        int row = times.indexOf(time);
        // Get the chosen day of week int value (1-7) to serve as col # of schedPaneList.
        int col = weekDayPicker.getValue().getValue() -1;
        // Add task.
        schedule[row][col].addTask(taskNameField.getText());
        statusLabel.setText("Task Added!");
        taskNameField.clear();
        randomTips();
        // Scroll to newly added task
        scrollPane.setVvalue(row*55 / schedPane.getHeight());
    }

    // Handle edit task button
    @FXML
    private void handleEditTask() {
        if (taskNameField.getText().isEmpty() ||
                timePicker.getSelectionModel().isEmpty() ||
                weekDayPicker.getSelectionModel().isEmpty()) {
            statusLabel.setText("Incomplete Input!");
            return;
        }
        String task = taskNameField.getText();
        int row = times.indexOf(timePicker.getValue());
        int col = weekDayPicker.getValue().getValue() -1;
        boolean isRemoved = schedule[row][col].removeTask(task);
        if (!isRemoved) {
            statusLabel.setText("Task not found!");
            return;
        }

        // Create edit task scene layout
        Label label = new Label("Edit Task");
        label.setId("header1");
        label.setMaxWidth(Double.MAX_VALUE);
        // Edit task name nodes
        Label label1 = new Label("Name: ");
        label1.setTextFill(Color.WHITE);
        label.setMaxWidth(Double.MAX_VALUE);
        TextField nameInput = new TextField();
        nameInput.setText(task);
        nameInput.getStyleClass().add("textFieldDarkBG");
        nameInput.setMaxWidth(Double.MAX_VALUE);
        // Edit time nodes
        Label label2 = new Label("Time: ");
        label2.setTextFill(Color.WHITE);
        label2.setMaxWidth(Double.MAX_VALUE);
        ComboBox<LocalTime> timeInput = new ComboBox<>();
        timeInput.getItems().addAll(times);
        timeInput.getSelectionModel().select(row);
        timeInput.setMaxWidth(Double.MAX_VALUE);
        timeInput.setStyle("-fx-border-color: transparent");
        // Edit day of week nodes
        Label label3 = new Label("Day of Week: ");
        label3.setTextFill(Color.WHITE);
        ComboBox<DayOfWeek> dayInput = new ComboBox<>();
        dayInput.getItems().addAll(DayOfWeek.values());
        dayInput.setValue(DayOfWeek.of(col+1));
        dayInput.setMaxWidth(Double.MAX_VALUE);
        dayInput.setStyle("-fx-border-color: transparent");
        // GridPane for edits
        GridPane gridPane = new GridPane();
        gridPane.addRow(0, label1, nameInput);
        gridPane.addRow(1, label2, timeInput);
        gridPane.addRow(2, label3, dayInput);
        gridPane.setHgap(10);
        gridPane.setVgap(20);
        gridPane.setAlignment(Pos.CENTER);
        // Save edit button
        Button btn = new Button("Save Edit");
        btn.getStyleClass().add("buttonDarkBG");
        btn.setAlignment(Pos.CENTER);
        // VBox (scene)
        VBox vbox = new VBox(label, gridPane, btn);
        vbox.getStylesheets().add("styles/mainStylesheet.css");
        vbox.getStyleClass().add("vbox");
        vbox.setSpacing(30);
        vbox.setPadding(new Insets(50));
        // Swap scene
        Scene primaryScene = taskNameField.getScene();
        Stage stage = (Stage) taskNameField.getScene().getWindow();
        stage.setScene(new Scene(vbox, 350, 400));
        // Successful edit actions
        btn.setOnAction(e -> {
            schedule[getTimeIdx(timeInput.getValue())][dayInput.getValue().getValue()-1].
                    addTask(nameInput.getText());
            stage.setScene(primaryScene);
        });
        statusLabel.setText("Task edits processed successfully!");
        taskNameField.clear();
        randomTips();
        // Scroll to newly added task
        scrollPane.setVvalue(row*55 / schedPane.getHeight());
    }

    // Handle remove task button
    @FXML
    private void handleRemoveTask() {
        if (taskNameField.getText().isEmpty() ||
                timePicker.getSelectionModel().isEmpty() ||
                weekDayPicker.getSelectionModel().isEmpty()) {
            statusLabel.setText("Incomplete Input!");
            return;
        }
        String task = taskNameField.getText();
        int row = times.indexOf(timePicker.getValue());
        int col = weekDayPicker.getValue().getValue() -1;
        boolean isRemoved = schedule[row][col].removeTask(task);
        if (!isRemoved) {
            statusLabel.setText("Task not found!");
        } else {
            statusLabel.setText("Task removed successfully!");
        }
        taskNameField.clear();
        randomTips();
        // Scroll to newly added task
        scrollPane.setVvalue(row*55 / schedPane.getHeight());
    }

    // Initialize new schedule with blank timeslots (no tasks).
    private void initializeSchedule() {
        for (int i = 0; i < times.size(); i++) {
            for (DayOfWeek day : DayOfWeek.values()) {
                ObservableList<String> list = FXCollections.observableArrayList();
                schedule[i][day.getValue()-1] = new Timeslot(times.get(i), day, list);
            }
        }
    }

    // Set-up schedule and schedPane to display new/blank schedule.
    // Assumes that schedPane has been cleared prior to calling this method.
    private void setupSchedPane() {
        for (int row = 0; row < times.size(); row++) {
            // Display time to schedPane as row header.
            Label label = new Label(times.get(row).toString());
            label.getStyleClass().clear();
            label.getStyleClass().add("gridCellRowHeader");
            schedPane.add(label, 0, row);
            // Display tasksList for each day of week in schedPane.
            for (DayOfWeek day: DayOfWeek.values()) {
                ListView<String> listView = new ListView<>();
                listView.setItems(schedule[row][day.getValue()-1].getTasksList());
                schedPane.add(listView, day.getValue(), row);
            }
        }
    }

    // Save schedule in an existing text file by writing the contents to schedPath.
    public static void saveSched() {
        StringBuilder content = new StringBuilder();
        String temp;
        if (schedPath == null) return;
        // Format for each timeslot: <time>|<day>|<tasks separated by ::>
        // General delimiter:  "|"     Tasks delimiter: "::"
        for (Timeslot[] time : schedule) {
            for (Timeslot timeslot : time) {
                content.append(timeslot.getTime().toString()).append("|");
                content.append(timeslot.getDayInt()).append("|");
                // Iterate thru each task in timeslot's task lists
                Iterator<String> iterator = timeslot.getTasksList().iterator();
                if (iterator.hasNext()) {
                    temp = iterator.next();
                    content.append(temp);
                    while (iterator.hasNext()) {
                        temp = iterator.next();
                        content.append("::").append(temp);
                    }
                }
                content.append("\r");
            }
        }
        // Write content to schedule's text file whose path is pointed to by schedPath
        try { Files.writeString(schedPath, content); }
        catch (IOException e) { e.printStackTrace(); }
    }

    // Read schedule contents from text file pointed by schedPath to schedule.
    // Main reference: https://www.baeldung.com/java-read-lines-large-file
    private void loadSched() {
        FileInputStream inputStream = null;
        Scanner sc = null;
        boolean flag = false;
        try {
            inputStream = new FileInputStream(String.valueOf(schedPath));
            sc = new Scanner(inputStream, StandardCharsets.UTF_8);
            if (sc.hasNextLine()) flag = true;
            while (sc.hasNextLine()) {
                // Get timeslot attributes (time, day, tasks)
                String[] items = sc.nextLine().split("\\|");
                LocalTime time = LocalTime.parse(items[0]);
                DayOfWeek day = DayOfWeek.of(Integer.parseInt(items[1]));
                // Get tasks
                ObservableList<String> list;
                if (items.length == 2) {  // when there's no task
                    list = FXCollections.observableArrayList();
                } else {
                    String[] tasks = items[2].split("::");
                    list = FXCollections.observableArrayList(tasks);
                }
                // Add timeslot to schedule
                schedule[getTimeIdx(time)][day.getValue()-1] = new Timeslot(time, day, list);
            }
            if (sc.ioException() != null) {
                throw sc.ioException();  // since Scanner suppresses exceptions
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (!flag) initializeSchedule();
            if (inputStream != null) {
                try { inputStream.close(); }
                catch (IOException e) { e.printStackTrace(); }
            }
            if (sc != null) {
                sc.close();
            }
        }
    }

    // Computes for the index of a specified time that should be in times list and returns it.
    private int getTimeIdx(LocalTime time) {
        return (int) Math.ceil(Duration.
                between(LocalTime.MIDNIGHT, time).toMinutes() / 30.0);
    }

    // Setter for username; to be called in Main class after loading the mainController.
    // Also checks if a directory of username exists, if not, it creates one.
    public void setUserDirectory(String username) {
        this.userDir = "databases/" + username;
        if (!Files.isDirectory(Path.of(userDir))) {
            try {
                Files.createDirectory(Path.of(userDir));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        userDir = userDir.concat("/");
    }

    private void disableTaskControls(boolean bool) {
        addTaskBtn.setDisable(bool);
        editTaskBtn.setDisable(bool);
        removeTaskBtn.setDisable(bool);
        taskNameField.setDisable(bool);
        timePicker.setDisable(bool);
        weekDayPicker.setDisable(bool);
    }

}
