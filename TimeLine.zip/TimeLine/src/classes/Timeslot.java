/* Timeslot class contains the variables for each timeslot in the schedule,
* namely: time, day of week, and names of the tasks scheduled for that timeslot. */

package classes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.DayOfWeek;
import java.time.LocalTime;

public class Timeslot {
    private final LocalTime time;
    private final DayOfWeek day;
    private final ObservableList<String> tasksList;

    public Timeslot(LocalTime time, DayOfWeek day, ObservableList<String> tasksList) {
        this.time = time;
        this.day = day;
        this.tasksList = tasksList;
    }

    public Timeslot(LocalTime time, DayOfWeek day, String name) {
        this.time = time;
        this.day = day;
        this.tasksList = FXCollections.observableArrayList(name);
    }

    public LocalTime getTime() {
        return time;
    }
    public int getDayInt() {
        return day.getValue();
    }
    public ObservableList<String> getTasksList() {
        return tasksList;
    }
    public void addTask(String name) {
        this.tasksList.add(name);
    }
    public boolean removeTask(String name) {
        if (tasksList.contains(name)) {
            tasksList.remove(name);
            return true;
        } else {
            return false;
        }
    }

}
